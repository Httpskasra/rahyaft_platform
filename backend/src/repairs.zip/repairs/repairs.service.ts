/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateRepairDto } from './dto/create-repair.dto';
import { AssignTechnicianDto } from './dto/assign-technician.dto';
import { RepairStatusService } from './services/repair-status.service';
import { RepairCaseNumberService } from './services/repair-case-number.service';
import { PrismaService } from '../prisma/prisma.service';
import { RepairStatus } from 'src/generated/prisma/enums';

@Injectable()
export class RepairsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly caseNumberService: RepairCaseNumberService,
    private readonly statusService: RepairStatusService,
  ) {}

  async create(dto: CreateRepairDto) {
    const customer = await this.prisma.customer.findUnique({
      where: {
        id: dto.customerId,
      },
    });

    if (!customer) {
      throw new NotFoundException('Customer not found');
    }

    const caseNumber = await this.caseNumberService.generate();

    return this.prisma.repairCase.create({
      data: {
        caseNumber,

        customerId: dto.customerId,

        deviceTitle: dto.deviceTitle,

        serialNumber: dto.serialNumber,

        problemDescription: dto.problemDescription,

        type: dto.type,

        status: RepairStatus.REGISTERED,
      },

      include: {
        customer: true,
      },
    });
  }

  async findAll() {
    return this.prisma.repairCase.findMany({
      include: {
        customer: true,
        technician: true,
      },

      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  async findOne(id: string) {
    const repair = await this.prisma.repairCase.findUnique({
      where: { id },

      include: {
        customer: true,
        technician: true,
        visits: true,
        parts: true,
        statusLogs: true,
      },
    });

    if (!repair) {
      throw new NotFoundException('Repair case not found');
    }

    return repair;
  }

  async assignTechnician(repairId: string, dto: AssignTechnicianDto) {
    const repair = await this.prisma.repairCase.findUnique({
      where: {
        id: repairId,
      },
    });

    if (!repair) {
      throw new NotFoundException('Repair case not found');
    }

    const technician = await this.prisma.user.findUnique({
      where: {
        id: dto.technicianId,
      },
    });

    if (!technician) {
      throw new NotFoundException('Technician not found');
    }

    return this.prisma.repairCase.update({
      where: {
        id: repairId,
      },

      data: {
        technicianId: dto.technicianId,
      },

      include: {
        technician: true,
      },
    });
  }
  async changeStatus(
    repairId: string,
    newStatus: RepairStatus,
    userId: string,
    reason?: string,
  ) {
    const repair = await this.prisma.repairCase.findUnique({
      where: { id: repairId },
    });

    if (!repair) {
      throw new NotFoundException('Repair not found');
    }

    // 1. Validate State Machine
    this.statusService.validateTransition(repair.status, newStatus);

    return this.prisma.$transaction(async (tx) => {
      // 2. Update Repair
      const updated = await tx.repairCase.update({
        where: { id: repairId },
        data: {
          status: newStatus,
        },
      });

      // 3. Log
      await tx.repairStatusLog.create({
        data: {
          repairCaseId: repairId,
          oldStatus: repair.status,
          newStatus,
          changedById: userId,
          reason,
        },
      });

      // 4. Notification Event (future integration)
      await tx.notificationEvent.create({
        data: {
          repairCaseId: repairId,
          status: newStatus,
          payload: {
            oldStatus: repair.status,
            newStatus,
            reason: reason ?? null,
          },
        },
      });

      return updated;
    });
  }
}

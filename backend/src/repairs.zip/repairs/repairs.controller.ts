/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { Body, Controller, Get, Param, Patch, Post, Req } from '@nestjs/common';

import { RepairsService } from './repairs.service';

import { CreateRepairDto } from './dto/create-repair.dto';
import { AssignTechnicianDto } from './dto/assign-technician.dto';
import { UpdateRepairStatusDto } from './dto/update-repair-status.dto';

@Controller('repairs')
export class RepairsController {
  constructor(private readonly repairsService: RepairsService) {}

  @Post()
  create(
    @Body()
    dto: CreateRepairDto,
  ) {
    return this.repairsService.create(dto);
  }

  @Get()
  findAll() {
    return this.repairsService.findAll();
  }

  @Get(':id')
  findOne(
    @Param('id')
    id: string,
  ) {
    return this.repairsService.findOne(id);
  }

  @Patch(':id/assign')
  assignTechnician(
    @Param('id')
    id: string,

    @Body()
    dto: AssignTechnicianDto,
  ) {
    return this.repairsService.assignTechnician(id, dto);
  }

  @Patch(':id/status')
  changeStatus(
    @Param('id') id: string,
    @Body() dto: UpdateRepairStatusDto,
    @Req() req: any,
  ) {
    return this.repairsService.changeStatus(
      id,
      dto.status,
      req.user.id,
      dto.reason,
    );
  }
}

import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';

import { PrismaModule } from './prisma/prisma.module';
import { RedisModule } from './redis/radis.module';
import { RabbitMQModule } from './rabbitmq/rabbitmq.module';

import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { RolesModule } from './roles/roles.module';
import { DepartmentsModule } from './departments/departments.module';
import { FormsModule } from './forms/forms.module';
import { FormSubmissionsModule } from './form-submissions/form-submissions.module';

import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { PermissionGuard } from './common/guards/permission.guard';

import { ApprovalsModule } from './approvals/approvals.module';

import { UserInfoModule } from './user-info/user-info.module';
import { BaleModule } from './bale/bale.module';
import { HealthModule } from './health/health.module';
import { AttendanceModule } from './attendance/attendance.module';
import { RepairsModule } from './repairs/repairs.module';
import { CustomerModule } from './customer/customer.module';
// import { PermissionsGuard } from './auth/permissions.guard';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 100 }]),
    PrismaModule,
    RedisModule,
    RabbitMQModule,
    AuthModule,
    UsersModule,
    RolesModule,
    DepartmentsModule,
    FormsModule,
    FormSubmissionsModule,
    ApprovalsModule,
    UserInfoModule,
    BaleModule,
    HealthModule,
    AttendanceModule,
    RepairsModule,
    CustomerModule,
  ],
  providers: [
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: PermissionGuard },
  ],
})
export class AppModule {}
